# WingMate (front end, TypeScript)

Cathay Pacific hackathon project. Pages: sign up, log in, dashboard.

## Just open it

Double-click **`dist/login.html`** (or `signup.html`, `dashboard.html`).

Every file in `dist/` is **self-contained**: its CSS, scripts and images are built into the HTML,
so it looks right wherever it is opened, even copied on its own into another folder. The only
thing the pages need is each other for the links (Log in -> dashboard.html), so keep them in one folder.

> The files in `src/pages/` are *unbuilt source templates* and have no design on their own.
> Always open the pages in `dist/`.

## Change the code

```bash
npm install        # once
npm run dev        # rebuilds on every save and serves http://localhost:5173/login.html
npm run build      # one-off build into dist/
npm run check      # strict type-check + build
```

## Where things live

```
src/
  pages/            HTML source: index, login, signup, dashboard
  styles/           CSS: base (colours, fonts), auth (login + signup), login, dashboard
  ts/
    shared/         dom helpers, typed localStorage, form validation
    auth/           login.ts, signup.ts
    dashboard/
      main.ts       starts the app
      types.ts      shared types (Prefs, Passenger, ...)
      data.ts       sample passengers, trip packages, option lists  <- swap for your backend
      state.ts      saved state (prefs, connections, chats, profile)
      matching.ts   match score
      router.ts     tab switching
      actions.ts    button clicks
      ui.ts         toast and dialog
      views/        home, find, messages, games, prefs, profile
public/assets/      Cathay logo (white) and plane photo, built into the pages
build.mjs           builds src/ -> dist/
```

## Notes

- Brand: Cathay Jade `#006564` and the colour palette from the guidelines are in `src/styles/base.css`.
- Font: Cathay Sans is proprietary. Put the licensed files in `public/assets/fonts/` (see the README there)
  and rebuild. They get built into the pages too. Until then the pages fall back to Aktiv Grotesk, then Helvetica Neue.
- Login and sign up have a `TODO` where the real API call goes. All data is saved in the browser only.
