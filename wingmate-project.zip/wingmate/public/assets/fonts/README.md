# Cathay Sans (optional)

The Cathay brand guidelines use **Cathay Sans**. It is a proprietary font, so it is not included.

If you have the licensed files, put them here with these exact names and the pages will use them automatically:

- `CathaySans-Light.woff2`
- `CathaySans-Regular.woff2`
- `CathaySans-Medium.woff2`

Until then the pages fall back to Aktiv Grotesk, then Helvetica Neue.
