import { $ } from '../shared/dom';
import { isEmail, showFieldState, wireLiveValidation, wirePasswordToggles } from '../shared/forms';
import { KEYS, store } from '../shared/storage';

type FieldKey = 'first' | 'last' | 'email' | 'phone' | 'dob' | 'pw' | 'pw2' | 'terms';
type AgeCheck = { ok: true } | { ok: false; msg: string };

const MIN_AGE = 16;

/** 0 (empty) to 4 (strong). */
function passwordStrength(password: string): number {
  let points = 0;
  if (password.length >= 8) points++;
  if (/[a-z]/.test(password) && /[A-Z]/.test(password)) points++;
  if (/\d/.test(password)) points++;
  if (/[^A-Za-z0-9]/.test(password)) points++;
  return password ? Math.max(1, points) : 0;
}

function checkAge(value: string): AgeCheck {
  if (!value) return { ok: false, msg: 'Enter your date of birth.' };
  const born = new Date(value);
  const today = new Date();
  if (Number.isNaN(born.getTime()) || born > today) return { ok: false, msg: 'Enter a valid date of birth.' };
  let age = today.getFullYear() - born.getFullYear();
  const monthGap = today.getMonth() - born.getMonth();
  if (monthGap < 0 || (monthGap === 0 && today.getDate() < born.getDate())) age--;
  return age >= MIN_AGE ? { ok: true } : { ok: false, msg: `You must be ${MIN_AGE} or older to sign up.` };
}

function main(): void {
  const form = $<HTMLFormElement>('#form');
  const input = (id: string) => $<HTMLInputElement>(`#${id}`);

  wirePasswordToggles();

  input('pw').addEventListener('input', () => {
    $('#meter').dataset.s = String(passwordStrength(input('pw').value));
  });
  input('dob').max = new Date().toISOString().slice(0, 10);

  const rules: Record<FieldKey, () => boolean> = {
    first: () => input('first').value.trim().length > 0,
    last: () => input('last').value.trim().length > 0,
    email: () => isEmail(input('email').value),
    phone: () => /^\d{7,12}$/.test(input('phone').value.replace(/[\s\-()]/g, '')),
    dob: () => {
      const result = checkAge(input('dob').value);
      $('#dobMsg').textContent = result.ok ? '' : result.msg;
      return result.ok;
    },
    pw: () => input('pw').value.length >= 8,
    pw2: () => input('pw2').value === input('pw').value && input('pw2').value.length > 0,
    terms: () => input('terms').checked,
  };
  const keys = Object.keys(rules) as FieldKey[];
  const check = (key: FieldKey): boolean => showFieldState(key, rules[key]());

  for (const key of keys) wireLiveValidation(input(key), key, rules[key]);

  form.addEventListener('submit', (event) => {
    event.preventDefault();
    const allValid = keys.map(check).every(Boolean);
    if (!allValid) {
      document.querySelector<HTMLElement>('.field.error input, .field.error select')?.focus();
      return;
    }
    const first = input('first').value.trim();
    store.set(KEYS.user, { first, last: input('last').value.trim(), email: input('email').value.trim() });
    // TODO: replace with a real API call, e.g. POST /api/signup
    // { first, last, email, phone: countryCode + phone, dob, password }
    $('#name').textContent = first;
    $('#card').classList.add('success');
  });
}

main();
