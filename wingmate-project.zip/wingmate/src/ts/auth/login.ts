import { $ } from '../shared/dom';
import { isEmail, showFieldState, wireLiveValidation, wirePasswordToggles } from '../shared/forms';
import { KEYS, store } from '../shared/storage';

type FieldKey = 'email' | 'pw';

function main(): void {
  const form = $<HTMLFormElement>('#form');
  const input = (id: string) => $<HTMLInputElement>(`#${id}`);
  const banner = $('#banner');

  wirePasswordToggles();

  // "Remember me" keeps the email address only, never the password.
  const savedEmail = store.getText(KEYS.rememberedEmail);
  if (savedEmail) {
    input('email').value = savedEmail;
    input('remember').checked = true;
  }

  const rules: Record<FieldKey, () => boolean> = {
    email: () => isEmail(input('email').value),
    pw: () => input('pw').value.length > 0,
  };
  const keys = Object.keys(rules) as FieldKey[];
  const check = (key: FieldKey): boolean => showFieldState(key, rules[key]());

  for (const key of keys) {
    const el = input(key);
    wireLiveValidation(el, key, rules[key]);
    el.addEventListener('input', () => banner.classList.remove('show'));
  }

  form.addEventListener('submit', (event) => {
    event.preventDefault();
    const allValid = keys.map(check).every(Boolean);
    if (!allValid) {
      document.querySelector<HTMLElement>('.field.error input')?.focus();
      return;
    }
    if (input('remember').checked) store.setText(KEYS.rememberedEmail, input('email').value.trim());
    else store.del(KEYS.rememberedEmail);
    // TODO: replace with a real API call, e.g. POST /api/login { email, password }
    // If it fails, show the error banner: banner.classList.add('show');
    $('#card').classList.add('success');
  });
}

main();
