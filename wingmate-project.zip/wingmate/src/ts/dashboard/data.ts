/**
 * Sample data for the demo: the passengers on CX 543, trip packages and game words.
 * Replace PEOPLE / TRIPS with real API results when the back end is ready.
 */
import type { Person, Trip } from './types';

type PersonSeed = Omit<Person, 'av'>;

const SEEDS: PersonSeed[] = [
  { id: 'p1', name: 'Mina Takahashi', type: 'Leisure', why: 'travel', pers: 'Ambivert', interests: ['Food & dining', 'Photography', 'Culture & museums', 'Art & design'], awake: 'No preference', seat: 'Window', bio: 'First time in Tokyo. Planning ramen stops and gallery afternoons.' },
  { id: 'p2', name: 'Daniel Wong', type: 'Business', why: 'meet', pers: 'Introvert', interests: ['Business networking', 'Tech & startups', 'Food & dining'], awake: 'Mostly awake', seat: 'Aisle', bio: 'Heading to a fintech conference. Happy to swap notes over coffee.' },
  { id: 'p3', name: 'Priya Nair', type: 'Study', why: 'travel', pers: 'Extrovert', interests: ['Photography', 'Hiking & outdoors', 'Music & concerts', 'Nightlife'], awake: 'Mostly awake', seat: 'Window', bio: 'Exchange semester starts soon. Looking for people to explore with.' },
  { id: 'p4', name: 'Sophie Laurent', type: 'Family', why: 'cab', pers: 'Ambivert', interests: ['Food & dining', 'Culture & museums', 'Shopping'], awake: 'Mostly asleep', seat: 'Aisle', bio: 'Travelling with two kids. Would love to split a cab from the airport.' },
  { id: 'p5', name: 'Kenji Mori', type: 'Leisure', why: 'travel', pers: 'Introvert', interests: ['Photography', 'Hiking & outdoors', 'Tech & startups'], awake: 'No preference', seat: 'Window', bio: 'Visiting for a week of trails and street photography.' },
  { id: 'p6', name: 'Aisha Rahman', type: 'Business', why: 'cab', pers: 'Ambivert', interests: ['Business networking', 'Wellness & spas', 'Shopping'], awake: 'Mostly asleep', seat: 'Aisle', bio: 'Short work trip. Sharing a cab to the city centre would be great.' },
  { id: 'p7', name: 'Lucas Chen', type: 'Study', why: 'meet', pers: 'Extrovert', interests: ['Music & concerts', 'Sports', 'Nightlife', 'Food & dining'], awake: 'Mostly awake', seat: 'Middle', bio: 'Backpacking for two weeks. Up for games and a chat on the flight.' },
  { id: 'p8', name: 'Hannah Becker', type: 'Leisure', why: 'travel', pers: 'Ambivert', interests: ['Culture & museums', 'Art & design', 'Photography', 'Food & dining'], awake: 'No preference', seat: 'Window', bio: 'Architecture fan with a long list of museums and cafes.' },
  { id: 'p9', name: 'Omar Haddad', type: 'Business', why: 'meet', pers: 'Extrovert', interests: ['Business networking', 'Sports', 'Food & dining'], awake: 'Mostly awake', seat: 'Aisle', bio: 'Regional sales lead. Always keen to meet people in other industries.' },
  { id: 'p10', name: 'Grace Lim', type: 'Family', why: 'travel', pers: 'Ambivert', interests: ['Shopping', 'Food & dining', 'Wellness & spas'], awake: 'Mostly asleep', seat: 'Middle', bio: 'Family holiday with my parents. Open to joining a group day out.' },
  { id: 'p11', name: 'Tomás Silva', type: 'Leisure', why: 'meet', pers: 'Introvert', interests: ['Art & design', 'Music & concerts', 'Culture & museums'], awake: 'No preference', seat: 'Window', bio: 'Quiet traveller who enjoys a good conversation and a good playlist.' },
  { id: 'p12', name: 'Yuki Tanaka', type: 'Study', why: 'cab', pers: 'Introvert', interests: ['Tech & startups', 'Photography', 'Hiking & outdoors'], awake: 'Mostly asleep', seat: 'Aisle', bio: 'Flying home for the holidays. Splitting a cab would save us both money.' },
];

export const PEOPLE: Person[] = SEEDS.map((seed, index) => ({ ...seed, av: index % 6 }));

export function findPerson(id: string | null): Person | undefined {
  return id === null ? undefined : PEOPLE.find((p) => p.id === id);
}

export const TRIPS: Trip[] = [
  { name: 'Tokyo highlights', days: 3, text: 'Classic sights, markets and a day trip.', tags: ['Culture & museums', 'Food & dining', 'Photography'] },
  { name: 'Food trail', days: 2, text: 'Ramen, izakaya and morning markets.', tags: ['Food & dining'] },
  { name: 'Art & design weekend', days: 2, text: 'Galleries, architecture and design stores.', tags: ['Art & design', 'Culture & museums', 'Shopping'] },
  { name: 'Nature escape', days: 3, text: 'Mountain trails and quiet shrines.', tags: ['Hiking & outdoors', 'Photography', 'Wellness & spas'] },
];

/** Canned replies for the demo chat. */
export const REPLIES = [
  'That sounds great. Which seat are you in?',
  'Same here, I am really looking forward to the trip.',
  'Do you want to plan a day out together once we land?',
  'Good idea. Let me check my itinerary and get back to you.',
  'I am up for a game of Hangman later if you are.',
  'Perfect, see you at the gate then.',
];

export const FLIGHT = { number: 'CX 543', from: 'HKG', to: 'HND', destination: 'Tokyo Haneda' } as const;

export const HANGMAN_WORDS = ['AIRPORT', 'SUITCASE', 'BOARDING', 'JETLAG', 'PASSPORT', 'LAYOVER', 'SOUVENIR', 'TURBULENCE', 'ITINERARY', 'WINDOW', 'LUGGAGE', 'DEPARTURE'];

/** One SVG fragment per wrong guess, drawn in order. */
export const HANGMAN_PARTS = [
  '<circle cx="145" cy="72" r="14"/>',
  '<path d="M145 86v52"/>',
  '<path d="M145 98l-22 20"/>',
  '<path d="M145 98l22 20"/>',
  '<path d="M145 138l-20 32"/>',
  '<path d="M145 138l20 32"/>',
];

export const SCRIBBLE_WORDS = ['Suitcase', 'Airplane', 'Sunset', 'Noodles', 'Passport', 'Mountain', 'Umbrella', 'Temple', 'Taxi', 'Skyline', 'Boarding pass', 'Camera'];

/** Cathay palette colours for the drawing pad: [hex, name]. */
export const SCRIBBLE_COLORS: ReadonlyArray<readonly [string, string]> = [
  ['#1b2626', 'Ink'],
  ['#006564', 'Cathay Jade'],
  ['#5E967E', 'Light Jade'],
  ['#C1B49A', 'Sand'],
  ['#C6C2C1', 'Slate'],
];
