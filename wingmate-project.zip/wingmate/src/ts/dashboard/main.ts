/**
 * Dashboard entry point. Wires the tabs together and starts the app.
 *
 *   data.ts      sample passengers, trips, game words
 *   options.ts   every choice (interests, seats ...) and the types derived from them
 *   state.ts     saved state (localStorage)
 *   matching.ts  match percentage and ranking
 *   router.ts    in-page tab switching
 *   views/*      one file per tab
 */
import { initActions } from './actions';
import { stageUI } from './flight';
import { registerRefresh, registerView, initRouter, show, startView } from './router';
import { initDialog, syncVisibleToggles, updateNavDot } from './ui';
import { initFind, renderFind } from './views/find';
import { initGames, renderPlayWith } from './views/games';
import { renderHome } from './views/home';
import { initMessages, onShowMessages, renderMessages } from './views/messages';
import { initPrefs, renderPrefs } from './views/prefs';
import { initProfile, renderProfile } from './views/profile';

/** Re-render everything that more than one tab depends on. */
function renderAll(): void {
  renderHome();
  renderFind();
  renderMessages();
  syncVisibleToggles();
  updateNavDot();
  stageUI();
}

function main(): void {
  // what to run when each tab opens
  registerView('home', renderHome);
  registerView('find', renderFind);
  registerView('messages', onShowMessages);
  registerView('games', renderPlayWith);
  registerView('prefs', renderPrefs);
  registerView('profile', renderProfile);
  registerRefresh(renderAll);

  initDialog();
  initRouter();
  initActions();
  initFind();
  initPrefs();
  initMessages();
  initGames();
  initProfile();

  renderAll();
  renderProfile();
  renderPrefs();
  show(startView(), false);
}

main();
