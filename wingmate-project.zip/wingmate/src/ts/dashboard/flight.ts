import { $ } from '../shared/dom';
import { FLIGHT } from './data';
import type { Stage } from './options';
import { state } from './state';

const DEPARTURE = new Date();
DEPARTURE.setDate(DEPARTURE.getDate() + 6);
DEPARTURE.setHours(9, 40, 0, 0);

const HOUR = 3600e3;
export const CHAT_WINDOW_HOURS = 48;

/** Time left before chats close, e.g. "44h 59m", or null once the 48 hours are over. */
export function closesIn(): string | null {
  if (state.landedAt === null) return null;
  const left = state.landedAt + CHAT_WINDOW_HOURS * HOUR - Date.now();
  if (left <= 0) return null;
  const hours = Math.floor(left / HOUR);
  const minutes = Math.floor((left % HOUR) / 60e3);
  return `${hours}h ${minutes}m`;
}

/** Chats are closed 48 hours after landing. */
export function chatClosed(): boolean {
  if (state.stage === 'closed') return true;
  return state.stage === 'landed' && state.landedAt !== null && closesIn() === null;
}

export function stageLabel(stage: Stage): string {
  const labels: Record<Stage, string> = {
    pre: 'Pre-flight chat',
    in: 'In-flight chat',
    landed: 'Chat open after landing',
    closed: 'Chat closed',
  };
  return labels[stage];
}

/** Updates the flight card on the home page and the "Flight stage" picker. */
export function stageUI(): void {
  const days = Math.max(1, Math.round((DEPARTURE.getTime() - Date.now()) / 864e5));
  const pill: Record<Stage, string> = {
    pre: `Departs in ${days} days`,
    in: 'You are in flight',
    landed: 'Landed',
    closed: 'Landed · chats closed',
  };
  const date = DEPARTURE.toLocaleDateString('en-GB', { weekday: 'short', day: 'numeric', month: 'short' });
  $('#stagePill').textContent = pill[state.stage];
  $('#flightMeta').textContent = `${FLIGHT.number} · ${date} · 09:40`;
  $<HTMLSelectElement>('#stage').value = state.stage;
}
