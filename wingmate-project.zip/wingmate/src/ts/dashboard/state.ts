/**
 * The app's single source of truth. Everything the dashboard remembers lives on `state`
 * and is saved to localStorage (see KEYS). Other modules import `state` and change it directly,
 * then call store.set(...) for whatever they changed.
 */
import { clone } from '../shared/dom';
import { KEYS, store } from '../shared/storage';
import {
  GOALS,
  INTERESTS,
  PERSONALITIES,
  PURPOSES,
  SEATING,
  SLEEPING,
  STAGES,
  TIERS,
  isOneOf,
  type Interest,
  type PrefKey,
  type Purpose,
  type Sleeping,
  type Stage,
  type ViewName,
} from './options';
import type { ChatMessage, Connection, FlyerInfo, Filters, Prefs, User } from './types';

export const DEFAULT_PREFS: Prefs = {
  type: 'Leisure',
  why: 'travel',
  pers: 'Ambivert',
  interests: ['Food & dining', 'Photography', 'Culture & museums'],
  awake: 'No preference',
  seat: 'Window',
};

const DEFAULT_USER: User = { first: 'Alex', last: 'Chan', email: 'alex.chan@example.com' };
const DEFAULT_FLYER: FlyerInfo = { num: '1234567890', tier: 'Silver' };
const DEFAULT_CRITERIA: Record<PrefKey, boolean> = { type: true, why: true, pers: true, interests: true, awake: true, seat: true };

/** Names used in earlier versions of the app, mapped to today's options. */
const LEGACY_PURPOSE: Record<string, Purpose | undefined> = { Solo: 'Leisure', Student: 'Study' };
const LEGACY_SLEEPING: Record<string, Sleeping | undefined> = { Yes: 'Mostly awake', No: 'Mostly asleep' };

export const emptyFilters = (): Filters => ({ type: '', why: '', pers: '', awake: '', seat: '' });

/** Turns whatever was saved (possibly old or damaged) into valid preferences. */
export function normalisePrefs(raw: unknown): Prefs {
  const r = (typeof raw === 'object' && raw !== null ? raw : {}) as Record<string, unknown>;
  const legacyType = typeof r.type === 'string' ? LEGACY_PURPOSE[r.type] : undefined;
  const legacyAwake = typeof r.awake === 'string' ? LEGACY_SLEEPING[r.awake] : undefined;
  return {
    type: isOneOf(PURPOSES, r.type) ? r.type : (legacyType ?? DEFAULT_PREFS.type),
    why: isOneOf(GOALS, r.why) ? r.why : DEFAULT_PREFS.why,
    pers: isOneOf(PERSONALITIES, r.pers) ? r.pers : DEFAULT_PREFS.pers,
    interests: Array.isArray(r.interests)
      ? r.interests.filter((i): i is Interest => isOneOf(INTERESTS, i))
      : [...DEFAULT_PREFS.interests],
    awake: isOneOf(SLEEPING, r.awake) ? r.awake : (legacyAwake ?? DEFAULT_PREFS.awake),
    seat: isOneOf(SEATING, r.seat) ? r.seat : DEFAULT_PREFS.seat,
  };
}

function loadPrefs(): Prefs {
  const saved = store.get<unknown>(KEYS.prefs, null);
  const prefs = normalisePrefs(saved);
  if (JSON.stringify(saved) !== JSON.stringify(prefs)) store.set(KEYS.prefs, prefs);
  return prefs;
}

function loadStage(): Stage {
  const saved = store.get<unknown>(KEYS.stage, 'pre');
  return isOneOf(STAGES, saved) ? saved : 'pre';
}

function loadFlyer(): FlyerInfo | null {
  const saved = store.get<Partial<FlyerInfo> | null>(KEYS.flyer, DEFAULT_FLYER);
  if (!saved) return null;
  return { num: saved.num ?? '', tier: isOneOf(TIERS, saved.tier) ? saved.tier : 'Green' };
}

function loadLastFlight(): string {
  const saved = store.get<string | null>(KEYS.lastFlight, null);
  if (saved) return saved;
  const date = new Date();
  date.setDate(date.getDate() - 40);
  const iso = date.toISOString();
  store.set(KEYS.lastFlight, iso);
  return iso;
}

export interface AppState {
  /** Saved preferences. */
  prefs: Prefs;
  /** Unsaved edits on the preferences page. */
  draft: Prefs;
  /** "Open to connect": whether other passengers can see you. */
  visible: boolean;
  /** Connection status by passenger id. */
  conn: Record<string, Connection | undefined>;
  chats: Record<string, ChatMessage[] | undefined>;
  /** Unread message count by passenger id. */
  unread: Record<string, number | undefined>;
  stage: Stage;
  /** When the flight landed (ms), used for the 48-hour chat window. */
  landedAt: number | null;
  /** Which preferences count towards the match percentage. */
  criteria: Record<PrefKey, boolean>;
  user: User;
  flyer: FlyerInfo | null;
  saveData: boolean;
  /** ISO date of the last flight, used for the 3-month data deletion notice. */
  lastFlight: string;
  /** Interest chips selected on the Find page. */
  interestFilter: Interest[];
  filters: Filters;
  activeChat: string | null;
  currentView: ViewName;
}

const prefs = loadPrefs();

export const state: AppState = {
  prefs,
  draft: clone(prefs),
  visible: store.get(KEYS.visible, true),
  conn: store.get(KEYS.conn, {}),
  chats: store.get(KEYS.chats, {}),
  unread: store.get(KEYS.unread, {}),
  stage: loadStage(),
  landedAt: store.get<number | null>(KEYS.landedAt, null),
  criteria: { ...DEFAULT_CRITERIA, ...store.get<Partial<Record<PrefKey, boolean>>>(KEYS.criteria, {}) },
  user: { ...DEFAULT_USER, ...store.get<Partial<User>>(KEYS.user, {}) },
  flyer: loadFlyer(),
  saveData: store.get(KEYS.saveData, true),
  lastFlight: loadLastFlight(),
  interestFilter: [],
  filters: emptyFilters(),
  activeChat: null,
  currentView: 'home',
};
