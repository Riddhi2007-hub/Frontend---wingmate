/**
 * Actions that cross tabs: the "Open to connect" switch and every button with a data-act
 * attribute (Connect, Message, "See mates who like this" ...).
 */
import { $, closest } from '../shared/dom';
import { KEYS, store } from '../shared/storage';
import { findPerson } from './data';
import { INTERESTS, isOneOf, type Interest } from './options';
import { emptyFilters, state } from './state';
import { refreshAll, show } from './router';
import { syncVisibleToggles, toast } from './ui';
import { addUnread, markRead, pushMessage } from './views/messages';
import type { Filters, Person } from './types';

const firstName = (person: Person): string => person.name.split(' ')[0] ?? person.name;

export function setVisible(visible: boolean): void {
  state.visible = visible;
  store.set(KEYS.visible, visible);
  syncVisibleToggles();
  refreshAll();
  toast(visible ? 'You are now open to connect' : 'You are hidden from other passengers');
}

/** Sends a request; the demo "accepts" it after a moment and the other person says hello. */
function connect(person: Person): void {
  if (!state.visible) {
    toast('Turn on “Open to connect” first');
    return;
  }
  state.conn[person.id] = 'requested';
  store.set(KEYS.conn, state.conn);
  refreshAll();
  toast(`Request sent to ${firstName(person)}`);

  window.setTimeout(() => {
    state.conn[person.id] = 'connected';
    store.set(KEYS.conn, state.conn);
    const opener =
      person.why === 'cab'
        ? 'Shall we share a cab after landing?'
        : person.why === 'travel'
          ? 'Fancy exploring together once we land?'
          : 'Looking forward to chatting on the flight.';
    pushMessage(person.id, 'them', `Hi ${state.user.first || 'there'}, glad we matched. ${opener}`);
    addUnread(person.id);
    refreshAll();
    toast(`${firstName(person)} accepted your request`);
  }, 1800);
}

/** Opens the Find tab with fresh filters. */
function openFind(filters: Partial<Filters>, interests: Interest[]): void {
  state.filters = { ...emptyFilters(), ...filters };
  state.interestFilter = interests;
  $<HTMLInputElement>('#q').value = '';
  show('find', true);
}

export function initActions(): void {
  $<HTMLInputElement>('#visibleToggle').addEventListener('change', (e) => setVisible((e.target as HTMLInputElement).checked));
  $<HTMLInputElement>('#visibleToggle2').addEventListener('change', (e) => setVisible((e.target as HTMLInputElement).checked));

  document.addEventListener('click', (event) => {
    const button = closest(event, '[data-act]');
    if (!button) return;
    const person = findPerson(button.dataset.id ?? null);

    switch (button.dataset.act) {
      case 'connect':
        if (person) connect(person);
        break;
      case 'message':
        if (person) {
          state.activeChat = person.id;
          markRead(person.id);
          show('messages', true);
        }
        break;
      case 'goVisible':
        setVisible(true);
        break;
      case 'clearFilters':
        $('#resetFilters').click();
        break;
      case 'tripmates': {
        const tag = button.dataset.tag;
        openFind({}, isOneOf(INTERESTS, tag) ? [tag] : []);
        break;
      }
      case 'cabmates':
        openFind({ why: 'cab' }, []);
        break;
      case 'bizmates':
        openFind({ type: 'Business' }, []);
        break;
      default:
        break;
    }
  });
}
