import { $ } from '../../shared/dom';
import { KEYS, store } from '../../shared/storage';
import { TIERS, isOneOf } from '../options';
import { refreshAll } from '../router';
import { state } from '../state';
import { ask, fmtDate, toast } from '../ui';

/** Saved frequent flyer details are deleted 3 months after the last flight. */
const RETENTION_MONTHS = 3;

function addMonths(date: string | Date, months: number): Date {
  const result = new Date(date);
  result.setMonth(result.getMonth() + months);
  return result;
}

export function renderProfile(): void {
  const { user, flyer, saveData } = state;
  $<HTMLInputElement>('#pfFirst').value = user.first;
  $<HTMLInputElement>('#pfLast').value = user.last;
  $<HTMLInputElement>('#pfEmail').value = user.email;

  $<HTMLInputElement>('#saveData').checked = saveData;
  $<HTMLInputElement>('#ffNum').value = saveData && flyer ? flyer.num : '';
  $<HTMLSelectElement>('#ffTier').value = flyer?.tier ?? 'Green';
  $('#ffFields').style.opacity = saveData ? '1' : '0.5';
  $<HTMLInputElement>('#ffNum').disabled = !saveData;
  $<HTMLSelectElement>('#ffTier').disabled = !saveData;

  const deleteOn = addMonths(state.lastFlight, RETENTION_MONTHS);
  const days = Math.round((deleteOn.getTime() - Date.now()) / 864e5);
  $('#retention').innerHTML = saveData
    ? `<b>Automatic deletion.</b> Your last flight was on ${fmtDate(state.lastFlight)}. If you do not fly with us again, your saved frequent flyer details are deleted on <b>${fmtDate(deleteOn)}</b> (${days > 0 ? `in ${days} days` : 'today'}). Flying again resets this.`
    : `<b>Nothing is being saved.</b> Your frequent flyer details are not stored. Turn the switch on if you would like us to remember them.`;
}

export function initProfile(): void {
  $<HTMLInputElement>('#saveData').addEventListener('change', (event) => {
    state.saveData = (event.target as HTMLInputElement).checked;
    renderProfile();
  });

  $('#pfSave').addEventListener('click', () => {
    state.user.first = $<HTMLInputElement>('#pfFirst').value.trim() || state.user.first;
    state.user.last = $<HTMLInputElement>('#pfLast').value.trim();
    store.set(KEYS.user, state.user);
    store.set(KEYS.saveData, state.saveData);

    if (state.saveData) {
      const tier = $<HTMLSelectElement>('#ffTier').value;
      state.flyer = { num: $<HTMLInputElement>('#ffNum').value.trim(), tier: isOneOf(TIERS, tier) ? tier : 'Green' };
      store.set(KEYS.flyer, state.flyer);
    } else {
      state.flyer = null;
      store.del(KEYS.flyer);
    }
    refreshAll();
    renderProfile();
    toast('Profile saved');
  });

  $('#ffDelete').addEventListener('click', () => {
    ask({
      title: 'Delete your saved data?',
      text: 'Your saved frequent flyer details will be removed now. This cannot be undone.',
      okLabel: 'Delete',
      danger: true,
      onOk: () => {
        state.flyer = null;
        store.del(KEYS.flyer);
        state.saveData = false;
        store.set(KEYS.saveData, false);
        renderProfile();
        toast('Your saved data has been deleted');
      },
    });
  });
}
