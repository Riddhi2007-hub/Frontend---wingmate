import { $, closest, esc } from '../../shared/dom';
import { KEYS, store } from '../../shared/storage';
import { REPLIES, findPerson } from '../data';
import { chatClosed, closesIn, stageLabel, stageUI } from '../flight';
import { STAGES, isOneOf } from '../options';
import { state } from '../state';
import { avatar, connectedPeople, fmtTime, updateNavDot } from '../ui';

/** Adds a message to a chat and saves it. */
export function pushMessage(id: string, from: 'me' | 'them', text: string): void {
  const thread = state.chats[id] ?? [];
  thread.push({ from, text, t: Date.now() });
  state.chats[id] = thread;
  store.set(KEYS.chats, state.chats);
}

export function markRead(id: string): void {
  state.unread[id] = 0;
  store.set(KEYS.unread, state.unread);
  updateNavDot();
}

export function addUnread(id: string): void {
  state.unread[id] = (state.unread[id] ?? 0) + 1;
  store.set(KEYS.unread, state.unread);
  updateNavDot();
}

/** Runs each time the Messages tab opens. */
export function onShowMessages(): void {
  if (state.activeChat) markRead(state.activeChat);
  renderMessages();
}

export function renderMessages(): void {
  const people = connectedPeople();
  if (!people.some((p) => p.id === state.activeChat)) state.activeChat = people[0]?.id ?? null;

  $('#convs').innerHTML = people.length
    ? people
        .map((p) => {
          const thread = state.chats[p.id] ?? [];
          const last = thread[thread.length - 1];
          const unread = state.unread[p.id];
          return `<button class="conv ${p.id === state.activeChat ? 'active' : ''}" data-chat="${esc(p.id)}">${avatar(p)}<span class="nm"><b>${esc(p.name)}</b><span>${last ? esc(last.text) : 'Say hello'}</span></span>${unread ? `<span class="ub">${unread}</span>` : ''}</button>`;
        })
        .join('')
    : `<div class="empty"><h3>No chats yet</h3><p>Connect with someone to start chatting.</p></div>`;

  const thread = $('#thread');
  const person = findPerson(state.activeChat);
  if (!person) {
    thread.innerHTML = `<div class="empty" style="align-self:center;grid-row:1/-1"><h3>Your chats will show here</h3><p style="margin-bottom:14px">Find a travel mate and send a connection request.</p><a class="btn" href="#find">Find travel mates</a></div>`;
    return;
  }

  const closed = chatClosed();
  let banner: string;
  if (state.stage === 'pre') banner = `<div class="banner">Pre-flight chat. You can keep chatting once you are on board.</div>`;
  else if (state.stage === 'in') banner = `<div class="banner">In-flight chat. Connected through the in-flight system.</div>`;
  else if (state.stage === 'landed' && !closed)
    banner = `<div class="banner warn">You have landed. This chat closes in ${closesIn() ?? '0h 0m'} (48 hours after landing).</div>`;
  else banner = `<div class="banner closed">This chat closed 48 hours after landing. You can no longer send messages.</div>`;

  const bubbles = (state.chats[person.id] ?? [])
    .map((m) => `<div class="bub ${m.from}">${esc(m.text)}<small>${fmtTime(m.t)}</small></div>`)
    .join('');

  thread.innerHTML = `
    <div class="th-head">${avatar(person)}<div class="nm"><b>${esc(person.name)}</b><span>${stageLabel(state.stage)}</span></div></div>
    ${banner}
    <div class="bubbles" id="bubbles" aria-live="polite">${bubbles}</div>
    <form class="composer" id="composer"><input type="text" id="msgInput" placeholder="${closed ? 'This chat is closed' : 'Write a message'}" ${closed ? 'disabled' : ''} aria-label="Message" autocomplete="off"><button class="btn" ${closed ? 'disabled' : ''}>Send</button></form>`;
  const scroller = $('#bubbles');
  scroller.scrollTop = scroller.scrollHeight;
}

export function initMessages(): void {
  // pick a conversation
  document.addEventListener('click', (event) => {
    const conv = closest(event, '[data-chat]');
    const id = conv?.dataset.chat;
    if (!id) return;
    state.activeChat = id;
    markRead(id);
    renderMessages();
  });

  // flight stage picker (demo control for the 48-hour rule)
  $<HTMLSelectElement>('#stage').addEventListener('change', (event) => {
    const value = (event.target as HTMLSelectElement).value;
    if (!isOneOf(STAGES, value)) return;
    state.stage = value;
    store.set(KEYS.stage, value);
    if (value === 'landed') state.landedAt = Date.now() - 3 * 3600e3;
    else if (value === 'closed') state.landedAt = Date.now() - 49 * 3600e3;
    else state.landedAt = null;
    store.set(KEYS.landedAt, state.landedAt);
    stageUI();
    renderMessages();
  });

  // send a message (the other person replies with a canned line after a moment)
  document.addEventListener('submit', (event) => {
    const form = event.target;
    if (!(form instanceof HTMLFormElement) || form.id !== 'composer') return;
    event.preventDefault();
    const text = $<HTMLInputElement>('#msgInput').value.trim();
    const id = state.activeChat;
    if (!text || !id || chatClosed()) return;

    pushMessage(id, 'me', text);
    renderMessages();
    $<HTMLInputElement>('#msgInput').focus();

    window.setTimeout(() => {
      pushMessage(id, 'them', REPLIES[Math.floor(Math.random() * REPLIES.length)] ?? REPLIES[0] ?? '');
      if (state.currentView === 'messages' && state.activeChat === id) renderMessages();
      else addUnread(id);
    }, 1400);
  });

  // keep the "closes in 44h 59m" countdown fresh
  window.setInterval(() => {
    const typing = document.activeElement?.matches('#msgInput') ?? false;
    if (state.stage === 'landed' && state.currentView === 'messages' && !typing) renderMessages();
  }, 60000);
}
