// Build script: TypeScript + CSS + images -> ONE self-contained HTML file per page in dist/.
//
//   npm run build      one-off build into dist/
//   npm run build:min  same, minified
//   npm run dev        rebuild on every save and serve http://localhost:5173/login.html
//
// Each dist/*.html has its CSS, JavaScript and images built in, so it works wherever it is opened:
// double-clicked, copied on its own into any folder, emailed, or shown in a preview.
// (Links between pages, like Log in -> dashboard.html, only need the pages to sit in the same folder.)
// The scripts are classic (IIFE) scripts, not ES modules, so they also run from file:// URLs.

import { build } from 'esbuild';
import { mkdir, readFile, readdir, rm, writeFile, access } from 'node:fs/promises';
import { watch } from 'node:fs';
import { createServer } from 'node:http';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.dirname(fileURLToPath(import.meta.url));
const dist = path.join(root, 'dist');
const args = new Set(process.argv.slice(2));
const minify = args.has('--minify');

const entries = {
  login: 'src/ts/auth/login.ts',
  signup: 'src/ts/auth/signup.ts',
  dashboard: 'src/ts/dashboard/main.ts',
};

const MIME = {
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.svg': 'image/svg+xml',
  '.webp': 'image/webp',
  '.woff2': 'font/woff2',
  '.woff': 'font/woff',
};

const exists = (file) => access(file).then(() => true, () => false);

async function dataUri(file) {
  const mime = MIME[path.extname(file).toLowerCase()];
  if (!mime) throw new Error(`Unknown file type for inlining: ${file}`);
  return `data:${mime};base64,${(await readFile(file)).toString('base64')}`;
}

/** Replaces every match using an async function (and a function replacer, so "$&" in code is never special). */
async function replaceAsync(text, regex, fn) {
  const matches = [...text.matchAll(regex)];
  const parts = await Promise.all(matches.map((m) => fn(...m)));
  let out = '';
  let last = 0;
  matches.forEach((m, i) => {
    out += text.slice(last, m.index) + parts[i];
    last = m.index + m[0].length;
  });
  return out + text.slice(last);
}

/** Inlines images, and optional fonts when the files exist (a missing font is dropped so nothing 404s). */
async function inlineCss(css) {
  // url("../assets/...") as an entry in a src: list, with its leading comma
  css = await replaceAsync(css, /,\s*url\(\s*["']?\.\.\/assets\/([^"')]+)["']?\s*\)(\s*format\([^)]*\))?/g, async (_all, rel, format = '') => {
    const file = path.join(root, 'public/assets', rel);
    return (await exists(file)) ? `,url("${await dataUri(file)}")${format}` : '';
  });
  // any other url(../assets/...)
  return replaceAsync(css, /url\(\s*["']?\.\.\/assets\/([^"')]+)["']?\s*\)/g, async (_all, rel) => `url("${await dataUri(path.join(root, 'public/assets', rel))}")`);
}

async function bundleScripts() {
  const result = await build({
    entryPoints: Object.fromEntries(Object.entries(entries).map(([name, file]) => [name, path.join(root, file)])),
    outdir: path.join(root, '.build'),
    bundle: true,
    write: false,
    format: 'iife',
    target: 'es2020',
    minify,
    logLevel: 'warning',
  });
  const scripts = {};
  for (const file of result.outputFiles) scripts[path.basename(file.path, '.js')] = file.text;
  return scripts;
}

async function buildSite() {
  const started = Date.now();
  const scripts = await bundleScripts();
  const styles = {};
  for (const file of await readdir(path.join(root, 'src/styles'))) {
    if (file.endsWith('.css')) styles[path.basename(file, '.css')] = await inlineCss(await readFile(path.join(root, 'src/styles', file), 'utf8'));
  }

  await rm(dist, { recursive: true, force: true });
  await mkdir(dist, { recursive: true });

  const pages = (await readdir(path.join(root, 'src/pages'))).filter((f) => f.endsWith('.html'));
  for (const page of pages) {
    let html = await readFile(path.join(root, 'src/pages', page), 'utf8');

    html = await replaceAsync(html, /<link rel="stylesheet" href="css\/([\w-]+)\.css">/g, async (_all, name) => {
      if (!(name in styles)) throw new Error(`${page}: no src/styles/${name}.css`);
      return `<style>\n${styles[name].trim()}\n</style>`;
    });
    html = await replaceAsync(html, /<script src="js\/([\w-]+)\.js"><\/script>/g, async (_all, name) => {
      if (!(name in scripts)) throw new Error(`${page}: no script entry named "${name}"`);
      // "</script" inside the code would end the tag early
      return `<script>\n${scripts[name].trim().replace(/<\/script/gi, '<\\/script').replace(/<!--/g, '<\\!--')}\n</script>`;
    });
    html = await replaceAsync(html, /(\ssrc=")assets\/([^"]+)(")/g, async (_all, a, rel, c) => `${a}${await dataUri(path.join(root, 'public/assets', rel))}${c}`);

    const leftovers = [...html.matchAll(/(?:src|href)="((?:css|js|assets)\/[^"]*)"/g)].map((m) => m[1]);
    if (leftovers.length) throw new Error(`${page}: still depends on separate files: ${leftovers.join(', ')}`);

    await writeFile(path.join(dist, page), html);
  }
  await rm(path.join(root, '.build'), { recursive: true, force: true });
  console.log(`Built ${pages.length} self-contained pages into dist/ in ${Date.now() - started}ms. Open dist/login.html in your browser.`);
}

await buildSite();

if (args.has('--watch')) {
  let timer;
  let busy = false;
  const rebuild = () => {
    clearTimeout(timer);
    timer = setTimeout(async () => {
      if (busy) return rebuild();
      busy = true;
      try {
        await buildSite();
      } catch (err) {
        console.error(String(err.message ?? err));
      }
      busy = false;
    }, 150);
  };
  for (const dir of ['src', 'public']) watch(path.join(root, dir), { recursive: true }, rebuild);

  const server = createServer(async (req, res) => {
    const url = new URL(req.url ?? '/', 'http://localhost');
    const name = path.basename(url.pathname) || 'login.html';
    try {
      const body = await readFile(path.join(dist, name));
      res.writeHead(200, { 'content-type': 'text/html; charset=utf-8', 'cache-control': 'no-store' });
      res.end(body);
    } catch {
      res.writeHead(404, { 'content-type': 'text/plain' });
      res.end('Not found');
    }
  });
  server.listen(5173, () => console.log('\nWingMate dev server: http://localhost:5173/login.html (rebuilds when you save)'));
}
